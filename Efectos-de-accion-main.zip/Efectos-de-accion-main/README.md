# Efectos-de-accion
3.7. Efectos de acción
